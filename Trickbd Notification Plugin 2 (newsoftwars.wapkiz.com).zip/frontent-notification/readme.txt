=== Frontent Notification Cracked By Rasel ===
Contributors: Rasel
Author: Rasel
Tags: notifications, report, admin notice
Requires at least: 3.0
Tested up to: 3.8
Stable tag: 9.0

The Frontent Notification Plugin for Wordpress! Notifications, Report Content and Admin Notice. 
== Description ==

Turn your blog into a social notifications.
Host your own notification system and login system needing any third party javascript or other code.

Compatibile with: Wordpress, Disqus Comment System

= The #1 Frontent Notification Wordpress =
*Increase Activity by delivering live notifications to users
*User role change notification to user.
*Comment moderation notification to user.
*Report post notification to user.
more...

= Get Started Quickly =
On install, then contact Admin for Activation code and let's start. for contact Fcebook: http://facebook.com/rtraselbd

<a href='http://facebook.com/rtraselbd'>**Contact Admin for activation code.**</a>

== Screenshots ==

1. Notification.
2. Report Page.
1. Shortcode.